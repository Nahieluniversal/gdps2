<?php
include "incl/comments/getGJComments.php";
?>