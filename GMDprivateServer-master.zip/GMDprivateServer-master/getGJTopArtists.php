<?php
include "incl/misc/getTopArtists.php";
?>
