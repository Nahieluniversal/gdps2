<?php
$redirect = 0;
/*
	Indicates wether the server should ask the main GD servers for the top artists list or not.
	If it's 0, it will fetch the most commonly used songs on the server by artists and list such up.
	If it's 1, it will ask the main servers for the list (which is not actively maintained).
*/
?>
